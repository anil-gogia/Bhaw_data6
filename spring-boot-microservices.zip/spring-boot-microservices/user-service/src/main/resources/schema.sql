create table customer(
      id int not null primary key,
      password varchar_ignorecase(50) not null
);
